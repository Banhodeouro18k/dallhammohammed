import Bard from "./classes/bard.js";

export default { Bard };
export { Bard };
